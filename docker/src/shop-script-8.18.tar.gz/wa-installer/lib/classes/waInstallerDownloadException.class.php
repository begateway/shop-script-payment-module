<?php

class waInstallerDownloadException extends waException {}
