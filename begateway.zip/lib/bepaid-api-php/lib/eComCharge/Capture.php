<?php
namespace eComCharge;

class Capture extends ChildTransaction {
}
?>
