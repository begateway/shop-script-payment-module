﻿<?php
return array(
    'name'        => 'beGateway',
    'description' => 'VISA, MasterCard',
    'icon'        => 'img/begateway16.png',
    'logo'        => 'img/begateway.png',
    'vendor'      => 'beGateway',
    'version'     => '1.2',
    'locale'      => array('en_EN','ru_RU'),
    'type'        => waPayment::TYPE_ONLINE,
);
