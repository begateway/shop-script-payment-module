#!/bin/bash

`which php` -f BeGateway.php
